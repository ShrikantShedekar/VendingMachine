using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProductDispensor;
using System;

namespace ProductDispensor.Test
{
    [TestClass]
    public class UnitTest
    {
        Coin coin;
        public UnitTest()
        {
            coin=new Coin();
        }
        [TestMethod]
        public void TestVerfiyInputStringForProduct()
        {
            string input="3";
            
            Dispensor disepnsor=new Dispensor();
            int result=disepnsor.VerifyInputStringForProduct(input);
            Assert.AreEqual(result.ToString(),input);
        }
        
        [TestMethod]
        public void VerifyNicklesCoin()
        {
            int Size =10;
            int Weight=10;
            decimal exepectedAmount=Convert.ToDecimal(0.05);
            
            VendingMachine machine=new VendingMachine();
            machine.ValidateInsertedCoin(Size,Weight,out coin); 
            
            Assert.AreEqual(exepectedAmount,coin.Amount,"VALID COIN");
        }
        [TestMethod]
        public void VerifyDimesCoin()
        {
            int Size =20;
            int Weight=20;
            decimal exepectedAmount=Convert.ToDecimal(0.1);
           
            VendingMachine machine=new VendingMachine();
            machine.ValidateInsertedCoin(Size,Weight,out coin); 
            
            Assert.AreEqual(exepectedAmount,coin.Amount,"VALID COIN");
        }
        [TestMethod]
        public void VerifyQuartersCoin()
        {
            int Size =30;
            int Weight=30;
            decimal exepectedAmount=Convert.ToDecimal(0.25);
            
            VendingMachine machine=new VendingMachine();
            machine.ValidateInsertedCoin(Size,Weight,out coin); 
            
            Assert.AreEqual(exepectedAmount,coin.Amount,"VALID COIN");
        }

        [TestMethod]
        public void VerifyPenniesCoin()
        {
            int Size =40;
            int Weight=40;
            decimal exepectedAmount=Convert.ToDecimal(0.01);
           
            VendingMachine machine=new VendingMachine();
            machine.ValidateInsertedCoin(Size,Weight,out coin); 
            if (coin==null)
                Assert.AreEqual(exepectedAmount,Convert.ToDecimal(0.01),"REJECTED COIN");
        }

        [TestMethod]
        public void VerifyValidCoin()
        {
            int Size =10;
            int Weight=20;

            VendingMachine machine=new VendingMachine();
            machine.ValidateInsertedCoin(Size,Weight,out coin); 
          
            Assert.IsNull(coin,"INVALID COIN");
        }
    }
}
