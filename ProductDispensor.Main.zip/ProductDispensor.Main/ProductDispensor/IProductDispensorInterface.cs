using ProductDispensor;
using System;

namespace ProductDispensor
{
    public interface IProductDispensorInterface  
    {  
         void DoProcess();  
    }
} 