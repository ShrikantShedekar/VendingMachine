using ProductDispensor;
using System;

namespace ProductDispensor
{
    public class AcceptCoin  : IProductDispensorInterface   
    {  
        public void DoProcess()  
        {  
            int coinSize=0;
            int coinWeight=0;
                        
            this.CaptureInput(out coinSize,out coinWeight);

                        
            VendingMachine machine=new VendingMachine();
            Coin insertedCoin=new Coin();
            
            machine.ValidateInsertedCoin(coinSize,coinWeight,out insertedCoin);

            if (insertedCoin == null)
            {
                Console.WriteLine("INVALID COIN"); 
                Console.WriteLine("INSERT COIN");
                Console.WriteLine("Total Available Coin Amount : $"+Calculate.Instance.Amount.ToString()); 
                            //break;   
            }
            else
            {
                Calculate.Instance.Amount = Calculate.Instance.Amount+ insertedCoin.Amount;
                Console.WriteLine("Total Available Coin Amount : $"+Calculate.Instance.Amount.ToString()); 
            }
           
        } 

        public void CaptureInput(out int coinSize,out int coinWeight)
        {
            string inputStrSize="";
            string inputStrWeight="";

            Console.WriteLine("Nickel Size :21, Weight:5 \t Dime Size:17, Weight:2 \t Quarter Size:24, Weight:6 \t Penny Size:19, Weight:2");
            Console.Write("\t Coin Size:");
            inputStrSize=Console.ReadLine();
            coinSize=ValidateInput(inputStrSize);
                        
            Console.WriteLine("\t Coin Weight:");
            inputStrWeight=Console.ReadLine();
            coinWeight=ValidateInput(inputStrWeight);
        } 

        public int ValidateInput(string inputString)
        {
            int cleanNum = 0;
            while (!int.TryParse(inputString, out cleanNum) )
            {
                Console.WriteLine("This is not valid input.");
                inputString = Console.ReadLine();
            }
            return cleanNum;
        }
    }  
}