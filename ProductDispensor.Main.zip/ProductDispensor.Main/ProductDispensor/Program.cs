﻿using System;

namespace ProductDispensor
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string numInput = "";
            int cleanNum = 0;
            Calculate.Instance.Amount=Convert.ToDecimal(0.00);
           
            do      //Loop should get executed Once, and should get continue till user exit
            {
                Console.WriteLine("Choose an option from following list:");
                Console.WriteLine("\t1 - Insert Coin");
                if  (Calculate.Instance.Amount >0)
                {
                    Console.WriteLine("\t2 - Select Product");
                    Console.WriteLine("\t3 - Exit");
                    Console.Write("Your option? ");
                    numInput=Console.ReadLine();
       
                    cleanNum=ValidateInput(numInput);
                }
                else
                {
                    cleanNum=1;
                }
                

                switch(cleanNum)
                {
                    case 1:              //Insert Coin 
                        AcceptCoin acceptCoin=new AcceptCoin();
                        acceptCoin.DoProcess();
                        break;
                    case 2:              //Get Product   
                        SelectProduct selectProduct=new SelectProduct();
                        selectProduct.DoProcess();
                        break;
                    case 3:
                        break;
                    default :
                        Console.WriteLine("This is not valid input.");
                        break; 
                }
     
            }while(cleanNum!=3);

      
        }
        
         static int ValidateInput(string inputString)
            {
                int cleanNum = 0;
                while (!int.TryParse(inputString, out cleanNum) )
                {
                    Console.WriteLine("This is not valid input.");
                    inputString = Console.ReadLine();
                }
                return cleanNum;
            }

        
    }
}
