using ProductDispensor;
using System;

namespace ProductDispensor
{
    public class SelectProduct  : IProductDispensorInterface   
    {  
        public void DoProcess()  
        {  
            if (Calculate.Instance.Amount <=0)
            {
                Console.WriteLine("INSERT COIN");
                Console.WriteLine("Total Available Coin Amount : $"+Calculate.Instance.Amount.ToString());
            }
            else
            {
                Console.WriteLine("Total Available Coin Amount : $"+Calculate.Instance.Amount.ToString());
                Dispensor dispensor = new Dispensor();
                Product releasedProduct =dispensor.DispenseProduct(Calculate.Instance.Amount);
                if (releasedProduct==null)
                {
                    Console.WriteLine("INSERT COIN");
                    Console.WriteLine("Total Available Coin Amount : $"+Calculate.Instance.Amount.ToString());
                }
                        
            }
            return;  
        }  
    }  
}