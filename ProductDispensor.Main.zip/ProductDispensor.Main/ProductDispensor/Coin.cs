using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductDispensor
{
    public class Coin
    {
        public string Name {get;set;}
        public int Size{ get; set; }
        public int Weight{ get; set; }
        public decimal Amount { get; set; }
    }
}
