using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductDispensor
{
    public class VendingMachine
    {
        List<Coin> coins = new List<Coin>();
        public VendingMachine()
        {
            this.InitializeCoins();   
        }
       
        public void ValidateInsertedCoin(int Size,int Weight,out Coin insertedCoin)
        {
            //Coin insertedCoin=new Coin();
            insertedCoin= coins.Where(i => i.Size == Size && i.Weight==Weight).FirstOrDefault();
            if (insertedCoin==null)
                return;

            if (insertedCoin.CoinType==CoinsType.penny)
            {
                
               Console.WriteLine("Rejected Coins :"+insertedCoin.CoinType);
                insertedCoin=null;
                return;
            }
         
        }



        private void InitializeCoins()
        {
            Coin coinNickels=new Coin();
            coinNickels.CoinType=CoinsType.nickel;
            coinNickels.Size=21;
            coinNickels.Weight=5;
            coinNickels.Amount=Convert.ToDecimal(0.05);
            coins.Add(coinNickels);

            Coin coinDimes=new Coin();
            coinDimes.CoinType=CoinsType.dime;
            coinDimes.Size=17;
            coinDimes.Weight=2;
            coinDimes.Amount=Convert.ToDecimal(0.10);
            coins.Add(coinDimes);

            Coin coinQuarter=new Coin();
            coinQuarter.CoinType=CoinsType.quarter;
            coinQuarter.Size=24;
            coinQuarter.Weight=6;
            coinQuarter.Amount=Convert.ToDecimal(0.25);
            coins.Add(coinQuarter);

            Coin coinPennies=new Coin();
            coinPennies.CoinType=CoinsType.penny;
            coinPennies.Size=19;
            coinPennies.Weight=2;
            coinPennies.Amount=Convert.ToDecimal(0.01);
            coins.Add(coinPennies);
        }
        
        
    }
}
